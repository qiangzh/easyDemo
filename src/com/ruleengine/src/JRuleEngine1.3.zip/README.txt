JRuleEngine Project
===================

Requirements
------------
- jsr94-1.1 jar file   See Java Specification Request 94

Note: jsr94.jar should be installed together with jruleengine.jar

Directory Structure
-------------------
src		source file of JRuleEngine project.

examples	examples of using JRuleEngine tool; it contains source and class files.

lib		jar files.

api		javadoc files.


How to use the library
----------------------

Please see examples included into the distribution.

This library is based on Java Specification Request 94, release 1.1.
Please see "Java Rule Engine API - JSR-94" document (file jsr94_spec.pdf) included in JSR-94 distribution:
this document explains how to use the current library (which is based on JSR-94).

Rules can be loaded in two modes:
- from an XML file (see xml files in examples)
- from LocalRuleExecutionSetProvider.createRuleExecutionSet method, passing a list of RuleImpl objects

A Rule is defined as:
- a name
- a description
- a list of Assumption objects, having the format: "leftTerm" ["operator" "rightTerm"]
  All assumptions are connected by an AND operator
  If assumption is in the form "leftTerm" "operator" "rightTerm", then the operator between left and right terms may be: "=", "<>", "contains", "notcontains", "<", ">", "<=", ">=" where the last 4 are applied only on numeric terms.
  If assumption has only leftTerm, then operator will be "exists" and the rule engine will control if leftTerm is contained in the working memory.
  A term may be a letteral (text, numeric value...) or a value obtained by a getter method of an object (ex. Customer.getCreditLimit) or a variable, identified by the prefix : (for example: ":X").
  Variables are allowed only as leftTerm and the operator must be "=" or "contains".
- a list of Action objects, having the format: "class.method" ["arg-1" "arg-2" ... "arg-N"]
  i.e. the "method" of "class" object is invoked, where "class" is in working memory (an object passed to the rule engine) or is created in that moment.
  "method" may have zero to N arguments.
  "arg-i" may be a term (see above).


